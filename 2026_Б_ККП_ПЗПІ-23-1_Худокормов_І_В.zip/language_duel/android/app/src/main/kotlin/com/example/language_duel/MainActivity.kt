package com.example.language_duel

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
